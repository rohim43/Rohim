global.bot = {
  name: "𔔡̤ Hawiyaa,",
  versions: "1.2.0",
  author: {
    name: "Hawiyaaa",
    number: "6289668590244",
  },
  media: {
    banner1: "https://files.catbox.moe/ivr2zv.jpg",
    banner2: "https://files.catbox.moe/0lwfus.jpg",
    icon1: "https://files.catbox.moe/r8uumm.jpg",
    icon2: "https://files.catbox.moe/r8uumm.jpg",
    icon3: "https://files.catbox.moe/r8uumm.jpg"
  },
  utils: {
    source_urls: "",
    title: "— hawiya 𝗆𝗎𝗅𝗍𝗂 𝖽𝖾𝗏𝗂𝖼𝖾",
    body: "simpled whatsapp bot.",
    newsletterJid: "@newsletter",
    newsletterName: "— hawiya 𝗆𝗎𝗅𝗍𝗂 𝖽𝖾𝗏𝗂𝖼𝖾"
  },
  key: {
    termai_api: "Bell409"
  }
}