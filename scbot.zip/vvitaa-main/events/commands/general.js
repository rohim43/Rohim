import { runtime, imgResize, font, getBuffer } from "#utils/tools";
import { contactQuoted, simpleQuoted } from '#library/fakeQuoted';
import db from "#utils/database";
import "#events/config";
import fs from "fs";

const thumbUrl = "https://files.catbox.moe/ivr2zv.jpg";

export default [
  {
    name: "menu",
    aliases: ["main", "help", "list"],
    description: "Menampilkan Menu Bot Utama",
    category: "General",
    execute: async (fuqi, ctx, msg) => {
      try {

        await fuqi.readMessages([ctx.key]);
        
        if (!global.loader || !global.loader.getCommandsByCategory) {
            throw new Error("Sistem loader command belum siap!");
        }

        const categories = global.loader.getCommandsByCategory();
        const totalFitur = Object.values(categories).flat().length;
        const tag = `@${ctx.sender.split("@")[0]}`;
        
        let menuText = `乂  *𝗕 𝗢 𝗧  𝗜 𝗡 𝗙 𝗢*

👋 Hai ${tag}, selamat datang

┏━━━〔 𝗨𝗦𝗘𝗥 𝗜𝗡𝗙𝗢 〕━━━┓
┃ 
┃ • *Nama:* ${msg.pushName || "User"}
┃ • *Nomor:* ${ctx.sender.split("@")[0]}
┃ • *Status:* ${global.db?.user?.[ctx.sender]?.status || "FREE USER"}
┃ • *Limit:* ${global.db?.user?.[ctx.sender]?.limit || "∞"}
┃ • *Level:* ${global.db?.user?.[ctx.sender]?.level || "1"}
┃ 
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗜𝗡𝗙𝗢 〕━━━┓
┃ 
┃ • *Bot Name:* ${global.bot?.name || "Park Jonggun"}
┃ • *Version:* v${global.bot?.versions || "2.1.0"}
┃ • *Platform:* Linux
┃ • *Runtime:* ${runtime(process.uptime())}
┃ • *Prefix:* [ Multi Prefix ]
┃ • *Total Fitur:* ${totalFitur} Fitur
┃ • *Library:* Baileys Multi-Device
┃ 
┗━━━━━━━━━━━━━━━━━━━━┛

*〔 𝗟𝗜𝗦𝗧  𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗬 〕*
Berikut adalah kategori fitur yang tersedia:
${Object.keys(categories).sort().map(cat => `  ◦  !allmenu ${cat.toLowerCase()}`).join("\n")}

\`〔 NOTE 〕\`
- Gunakan *!allmenu* untuk melihat semua list fitur secara detail.
- Jika ada fitur yang error, hubungi owner dengan ketik *.report [pesan]*.

_Bot aktif selama: ${runtime(process.uptime())}_`;

        await fuqi.sendMessage(
          ctx.id,
          {
            image: { url: thumbUrl },
            caption: menuText,
            mentions: [ctx.sender],
            contextInfo: {
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: global.bot?.utils?.newsletterJid || "1u0000@newsletter",
                newsletterName: "Updates & Info | " + (global.bot?.name || "Bot"),
              },
              externalAdReply: {
                title: `${global.bot?.name || "Bot"} Online`,
                body: "Powered by Node.js & Baileys",
                thumbnailUrl: thumbUrl,
                sourceUrl: global.bot?.utils?.source_urls || "https://github.com/",
                mediaType: 1,
                renderLargerThumbnail: true,
              },
            },
          },
          { quoted: contactQuoted(ctx) }
        );

      } catch (error) {
        console.error("❌ Error di Menu:", error);
        await ctx.reply(`System Error: ${error.message}`);
      }
    },
  },
  {
    name: "allmenu",
    aliases: ["all", "fitur"],
    description: "Menampilkan semua command secara lengkap",
    category: "General",
    execute: async (fuqi, ctx, msg) => {
      try {
        let categories = global.loader.getCommandsByCategory();
        let catName = ctx.args[0]?.toLowerCase();
        
        if (catName && categories[catName]) {
           let text = `*〔 CATEGORY: ${catName.toUpperCase()} 〕*\n\n`;
           categories[catName].forEach(cmd => {
             text += `◦ .${cmd.name}\n`;
           });
           return await ctx.reply(text);
        }

        let fullText = `乂  *𝗔 𝗟 𝗟  𝗠 𝗘 𝗡 𝗨  𝗟 𝗜 𝗦 𝗧*\n\n`;
        
        for (const [cat, cmds] of Object.entries(categories).sort()) {
           fullText += `*〔 ${cat.toUpperCase()} 〕*\n`;
           cmds.forEach(cmd => {
             fullText += ` ◦ .${cmd.name}\n`;
           });
           fullText += `\n`;
        }

        await fuqi.sendMessage(ctx.id, { 
            image: { url: thumbUrl },
            caption: fullText + `\n*Total:* ${Object.values(categories).flat().length} Commands`,
            contextInfo: {
                externalAdReply: {
                    title: "ALL COMMANDS LIST",
                    body: "Pilih fitur yang ingin kamu gunakan",
                    thumbnailUrl: thumbUrl,
                    mediaType: 1
                }
            }
        }, { quoted: msg });

      } catch (e) {
        console.error(e);
        await ctx.reply("Gagal memuat semua menu.");
      }
    }
  }
];